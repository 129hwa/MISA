#!/bin/bash
export CUDA_VISIBLE_DEVICES=0
export PYTHONPATH="/home/elicer/DomainBed:$PYTHONPATH"

DATASET="PACS" # DomainNet
DATA_DIR="/home/elicer/DomainBed/"
ALGORITHM="MISA"

BEST_MODEL=/home/elicer/DomainBed/sweeps/MIAS/fc81733e289f695c0cd144382758b9a0/model.pkl

# ResNet 기본 하이퍼파라미터 (use_clip=False가 기본값)
RESNET_HPARAMS='{
     "use_clip": false,
     "resnet18": false,
     "resnet50": true,
     "latent_dim": 512,
     "attention_heads": 4,
     "dropout_rate": 0.3,
     "lambda_task": 1.0,
     "lambda_inv_adv": 0.5,
     "lambda_spc_clf": 0.5,
     "lambda_disentangle": 0.2,
     "lambda_reconstruct": 0.5,
     "grl_alpha_max": 1.0,
     "grl_warmup_epochs": 1000,
     "use_spectral_loss": true,
     "lambda_spectral_inv": 0.2,
     "lambda_spectral_spc": 0.2,
     "gabor_num_filters": 8,
     "gabor_kernel_size": 11,
     "lr": 5e-5,
     "weight_decay": 5e-4
 }'
# 'gabor_num_filters': [4, 8, 16]
# 'gabor_kernel_size': [7, 11, 15]

# HPARAMS_LIST=(ABSPT_HPARAMS ALL_HPARAMS ABRC_HPARAMS ABDE_HPARAMS)
# for H in "${HPARAMS_LIST[@]}"; do
#   for TEST_ENV in 0 1 2 3; do
#     echo "================================================"
#     echo "Training MIAS-Res on PACS with test environment $TEST_ENV"
#     echo "================================================"
    
#     OUTPUT_DIR="./results/2t/${H}/${TEST_ENV}"
#     mkdir -p $OUTPUT_DIR
    
#     python -m domainbed.scripts.train \
#         --dataset PACS \
#         --algorithm MIAS \
#         --test_envs=$TEST_ENV \
#         --hparams "${!H}" \
#         --data_dir=$DATA_DIR \
#         --output_dir=$OUTPUT_DIR \
#         --steps=5000 \
#         --checkpoint_freq=1000 \
#         --seed=1 \
#     2>&1 | tee "${OUTPUT_DIR}/training.log"
    
#     echo "Completed test environment $TEST_ENV"
#     echo "Results saved to: $OUTPUT_DIR"
#     python -m domainbed.scripts.collect_results --input_dir /home/elicer/DomainBed/results/2t/${H}/ --latex
#   done
# done

# for TEST_ENV in 0 1 2 3; do
#   echo "================================================"
#   echo "Training MIAS-BASE on PACS with test environment $TEST_ENV"
#   echo "================================================"
  
#   OUTPUT_DIR="./results/2t/BASE_HPARAMS/${TEST_ENV}"
#   mkdir -p $OUTPUT_DIR
  
#   python -m domainbed.scripts.train \
#       --dataset PACS \
#       --algorithm MIAS \
#       --test_envs=$TEST_ENV \
#       --hparams "$BASE_HPARAMS" \
#       --data_dir=$DATA_DIR \
#       --output_dir=$OUTPUT_DIR \
#       --steps=5000 \
#       --checkpoint_freq=1000 \
#       --seed=1 \
#   2>&1 | tee "${OUTPUT_DIR}/training.log"
  
#   echo "Completed test environment $TEST_ENV"
#   echo "Results saved to: $OUTPUT_DIR"
#   python -m domainbed.scripts.collect_results --input_dir /home/elicer/DomainBed/results/2t/BASE_HPARAMS/ --latex
# done

# echo "All experiments completed!"


HPARAMS_JSON='{
  "algorithm": "MIAS",
  "batch_size": 64,
  "lr": 0.0001,
  "weight_decay": 0.0001,
  "latent_dim": 256,
  "attention_heads": 4,
  "dropout_rate": 0.3,
  
  "lambda_task": 1.0,
  "lambda_inv_adv": 0.5,
  "lambda_spc_clf": 0.5,
  "lambda_disentangle": 0.1,
  "lambda_orthogonal": 0.5,
  "lambda_reconstruct": 0.5,
  
  "use_spectral_loss": true,
  "lambda_spectral_inv": 0.5,
  "lambda_spectral_spc": 0.5,
  "invert_spc_spectral": true,
  
  "spectral_inv_schedule": "sigmoid",
  "spectral_inv_sigmoid_center": 0.3,
  "spectral_spc_schedule": "linear",
  "spectral_spc_warmup_steps": 1000,
  
  "gabor_num_filters": 8,
  "gabor_kernel_size": 11,
  "gabor_freeze_epoch": 2000,
  "lr_spectral": 0.0001,
  
  "use_multiscale_spectral": false,
  "lambda_spectral_layer1": 0.5,
  "lambda_spectral_layer2": 0.5,
  
  "pretrain_steps": 1000,
  "disable_spectral_pretrain": false,
  
  "grl_alpha_max": 1.0,
  "grl_warmup_steps": 1000,
  
  "use_combined": false,
  "use_filtered_reconstruction": true,
  
  "total_steps": 5000
}'

#for TEST_ENV in 0 1 2 3; do
#    echo "=== MIAS on PACS | test_env = ${TEST_ENV} ==="
#    python -m domainbed.scripts.train \
#        --data_dir $DATA_DIR \
 #       --output_dir ./results/NEW3/MIAS/PACS/${TEST_ENV}/ \
  #      --algorithm MIAS \
 #       --dataset VLCS \
#        --seed 42 \
  #      --test_envs ${TEST_ENV} \
#        --hparams "${HPARAMS_JSON}" \
   # > >(tee -a output_MIAS.log) \
    #2> >(tee -a error_MIAS.log >&2)
#done


# Sweep 실행 (선택사항)
# echo ""
# echo "To run hyperparameter sweep for MIAS-ResNet:"
# echo "================================================"

# SWEEP_DIR="./sweep_results/MIAS_ResNet50_${DATASET}_$(date +%Y%m%d_%H%M%S)"
# echo "python -m domainbed.scripts.sweep launch \\"
# echo "    --data_dir $DATA_DIR \\"
# echo "    --output_dir $SWEEP_DIR \\"
# echo "    --command_launcher local \\"
# echo "    --algorithms MIAS \\"
# echo "    --datasets $DATASET \\"
# echo "    --n_hparams 20 \\"
# echo "    --n_trials 3 \\"
# echo "    --steps 5000 \\"
# echo "    --hparams '$RESNET_HPARAMS' \\"
# echo "    --skip_confirmation"

# # CLIP 기반 MIAS 하이퍼파라미터
CLIP_HPARAMS="{\"vit\": true, \"resnet50_augmix\": false, \"use_clip\": true, \"clip_model_name\": \"ViT-B/32\", \"freeze_clip\": false, \"latent_dim\": 512, \"attention_heads\": 4, \"dropout_rate\": 0.2, \"lambda_task\": 1.0, \"lambda_inv_adv\": 0.1, \"lambda_spc_clf\": 0.1, \"lambda_disentangle\": 0.05, \"lambda_reconstruct\": 0.5, \"grl_alpha_max\": 1.0, \"grl_warmup_epochs\": 1000, \"use_spectral_loss\": true, \"lambda_spectral_inv\": 0.2, \"lambda_spectral_spc\": 0.1, \"gabor_num_filters\": 8, \"gabor_kernel_size\": 11}"

# # for TEST_ENV in 0 1 2 3; do
# #   python -m domainbed.scripts.train \
# #     --data_dir $DATA_DIR \
# #     --output_dir ./results/SIMPLE_CLIP \
# #     --algorithm SIMPLE \
# #     --dataset PACS \
# #     --test_envs $TEST_ENV \
# #     --seed 42 \
# #     --hparams '{"model_pool": "vit_b16", "adapter_hidden":256, "matcher_hidden":128}'
# # done


# # echo "Starting Experiment 1: CLIP ViT-B/32 (frozen)"
# # python3 -m domainbed.scripts.train \
# #   --data_dir $DATA_DIR \
# #   --dataset $DATASET \
# #   --algorithm MIAS \
# #   --task domain_generalization \
# #   --hparams "$CLIP_HPARAMS" \
# #   --test_envs 3 \
# #   --output_dir /home/elicer/mias_output/spct0.5 \
# #   --holdout_fraction 0.2 \
# #   --seed 0 \
# #   --hparams_seed 0 \
# #   --trial_seed 0 \
# #   > outputTQ_${TEST_ENV}_${ALGORITHM}.log 2> errorTQ_${TEST_ENV}_${ALGORITHM}.log

# # ResNet 기반 MIAS 하이퍼파라미터 (비교용)
RESNET_HPARAMS="{\"use_clip\": true, \"latent_dim\": 512, \"attention_heads\": 4, \"dropout_rate\": 0.3, \"lambda_task\": 1.0, \"lambda_inv_adv\": 0.1, \"lambda_spc_clf\": 0.1, \"lambda_disentangle\": 0.0, \"lambda_reconstruct\": 0.1, \"grl_alpha_max\": 1.0, \"grl_warmup_epochs\": 1000, \"use_spectral_loss\": true, \"lambda_spectral_inv\": 0.1, \"lambda_spectral_spc\": 0.1, \"gabor_num_filters\": 8, \"gabor_kernel_size\": 11}" # 8, 11

# 기존 알고리즘들 실행
# for ALGORITHM in 'CDANN'; do
#  for TEST_ENV in 0 1 2 3; do
#    echo "Training $ALGORITHM on $DATASET with test environment $TEST_ENV"
#    OUTPUT_DIR="/home/elicer/DomainBed/results/${ALGORITHM}_s1_${DATASET}/env${TEST_ENV}"
#     mkdir -p $OUTPUT_DIR
#     python -m domainbed.scripts.train \
#       --dataset PACS \
#       --algorithm=$ALGORITHM \
#       --test_envs $TEST_ENV \
#       --data_dir=$DATA_DIR \
#       --output_dir=$OUTPUT_DIR \
#       --steps=5000 \
#       --checkpoint_freq=100 \
#       --seed=1 \
#       > output_${TEST_ENV}_s1_${ALGORITHM}.log 2> error_${TEST_ENV}_s1_${ALGORITHM}.log
#   done
# done

# # # MIAS-CLIP 실행
# # echo "Starting MIAS with CLIP experiments..."
# # for TEST_ENV in 0 1 2 3; do
# #     echo "Training MIAS-CLIP on $DATASET with test environment $TEST_ENV"
# #     OUTPUT_DIR="/home/elicer/DomainBed/results/MIAS_CLIP_${DATASET}_env${TEST_ENV}"
# #     mkdir -p $OUTPUT_DIR
# #     python -m domainbed.scripts.train \
# #         --dataset=$DATASET \
# #         --algorithm=MIAS \
# #         --test_envs $TEST_ENV \
# #         --hparams "$CLIP_HPARAMS" \
# #         --data_dir=$DATA_DIR \
# #         --output_dir=$OUTPUT_DIR \
# #         --steps=5000 \
# #         --checkpoint_freq=100 \
# #         --seed=42 \
# #     > output_${TEST_ENV}_MIAS_CLIP_${DATASET}.log 2> error_${TEST_ENV}_MIAS_CLIP_${DATASET}.log
# # # done
# # for TEST_ENV in 0 1 2 3; do
# #   python3 -m domainbed.scripts.train \
# #     --data_dir $DATA_DIR \
# #     --dataset $DATASET \
# #     --algorithm MIAS \
# #     --task domain_generalization \
# #     --hparams $CLIP_HPARAMS \
# #     --test_envs $TEST_ENV \
# #     --output_dir /home/elicer/DomainBed/results/MIAS_MI_${DATASET}_env${TEST_ENV} \
# #     --holdout_fraction 0.2 \
# #     --steps 5000 \
# #     --checkpoint_freq 100 \
# #     --seed 42 \
# #     2>&1 | tee outputTQ_${TEST_ENV}_${ALGORITHM}.log 2> errorTQ_${TEST_ENV}_${ALGORITHM}.log
# # done

# #MISA-ResNet 실행 (비교용)
echo "Starting MISA experiments..."
for TEST_ENV in 0 1 2 3; do
    echo "Training MISA-ViT on PACS with test environment $TEST_ENV"
    OUTPUT_DIR="/home/elicer/DomainBed/results/MISA_s1_PPPPPACS/env${TEST_ENV}"
    mkdir -p $OUTPUT_DIR
    python -m domainbed.scripts.train \
        --dataset PACS \
        --algorithm=MISA \
        --test_envs $TEST_ENV \
        --hparams "$RESNET_HPARAMS" \
        --data_dir=$DATA_DIR \
        --output_dir=$OUTPUT_DIR \
        --steps=5000 \
        --checkpoint_freq=500 \
        --seed=1 \
    > output_pa_CLIP_${TEST_ENV}.log 2> error_pa_MISA_CLIP_${TEST_ENV}.log
done

for TEST_ENV in 0 1 2 3; do
    echo "Training MISA-ViT on PACS with test environment $TEST_ENV"
    OUTPUT_DIR="/home/elicer/DomainBed/results/MISA_s0_PPPPPACS/env${TEST_ENV}"
    mkdir -p $OUTPUT_DIR
    python -m domainbed.scripts.train \
        --dataset PACS \
        --algorithm=MISA \
        --test_envs $TEST_ENV \
        --hparams "$RESNET_HPARAMS" \
        --data_dir=$DATA_DIR \
        --output_dir=$OUTPUT_DIR \
        --steps=5000 \
        --checkpoint_freq=500 \
        --seed=0 \
    > output_pa_CLIP_${TEST_ENV}.log 2> error_pa_MISA_CLIP_${TEST_ENV}.log
done

# # echo "Training completed."

# #!/bin/bash

# # 설정
# SWEEP_OUTPUT_BASE="/home/elicer/DomainBed/sweep_results/MISA_ResNet_${DATASET}"
# TIMESTAMP=$(date +%Y%m%d_%H%M%S)
# SWEEP_OUTPUT_DIR="${SWEEP_OUTPUT_BASE}_${TIMESTAMP}"

# echo "Starting MIAS-ResNet sweep for $DATASET"
# echo "Output directory: $SWEEP_OUTPUT_DIR"

# mkdir -p "$SWEEP_OUTPUT_DIR"

# # hparams 설정
# #HPARAMS='{"use_clip": true, "clip_model_name": "ViT-B/32", "freeze_clip": true}'

# # 미완료 작업 삭제
# python -m domainbed.scripts.sweep delete_incomplete \
#     --data_dir /home/elicer/DomainBed/ \
#     --output_dir /home/elicer/DomainBed/sweep_results/MIAS_ResNet_2 \
#     --command_launcher local \
#     --algorithms MIAS ERM Mixup SagNet GroupDRO IRM MLDG \
#     --datasets PACS VLCS \
#     --n_hparams 20 \
#     --n_trials 3 \
#     --skip_confirmation

# sweep 실행
# python -m domainbed.scripts.sweep launch \
#     --data_dir "$DATA_DIR" \
#     --output_dir "$SWEEP_OUTPUT_DIR" \
#     --command_launcher local \
#     --algorithms MIAS ERM Mixup SagNet GroupDRO IRM MLDG \
#     --datasets PACS VLCS \
#     --n_hparams 3 \
#     --n_trials 1 \
#     --steps 1000 \
#     --seed 42 \
#     --skip_confirmation \
#     2>&1 | tee "${SWEEP_OUTPUT_DIR}/sweep_log.log"

# # --single_test_envs \
# # echo "Sweep launched. Check $SWEEP_OUTPUT_DIR for progress."
# # echo "To collect results later, run:"
# echo "python -m domainbed.scripts.collect_results --input_dir \"$SWEEP_OUTPUT_DIR\" --latex"

# python -m domainbed.scripts.collect_results --input_dir /home/elicer/DomainBed/results/ViT_PACS --latex
